/*
Genera la classe StringArrayList che implementa una lista di stringhe con i metodi specificati.
addLast(String value): aggiunge la stringa value alla fine della lista, anche se value è null.
get(int index): restituisce la stringa all'indice index della lista. Se l'indice è fuori dai limiti, restituisce null.
removeAt(int index): rimuove la stringa all'indice index della lista, impostando quella posizione a null. Se l'indice è fuori dai limiti, non fa nulla.
removeFirst(String s): rimuove la prima occorrenza della stringa s nella lista, impostando quella posizione a null. Se la stringa non è presente, non fa nulla.
size(): restituisce il numero di elementi attualmente presenti nella lista.
toArray(): restituisce un array di stringhe contenente tutti gli elementi della lista, inclusi i null. Non esporre direttamente l'array interno.
compact(): rimuove tutti i null dalla lista, riducendo la dimensione della lista di conseguenza.
clear(): rimuove tutti gli elementi dalla lista, rendendola vuota.
Ragionare sul concetto di array ridimensionabile, con una logica di copia degli elementi in un nuovo array quando necessario.
Come sempre, è vietato utilizzare classi esterne all'infuori di String e Object.
*/
