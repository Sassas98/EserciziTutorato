public interface ParteLettera { }
